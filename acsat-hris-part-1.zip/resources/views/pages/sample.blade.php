@extends('hrms.layouts.base3')

@section('content')
<div class="content">
  <div class="container-fluid">
    {{ $data }}
  </div>
</div>
@endsection


@section('title')
  
@endsection

@section('crumbs')
  
@endsection

@push('scripts')
@endpush

@section('jsfunction')

@endsection

@push('styles')

@endpush