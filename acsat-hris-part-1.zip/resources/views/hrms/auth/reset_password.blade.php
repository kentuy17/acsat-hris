Dear {{$user->name}},

<br/><br/>
    Congratulations ! Your new password is {!! $string !!} .
<br />
<br />

Thanks & Regards
<br />
Human Resource Department
<br />
Digital IP Insights
