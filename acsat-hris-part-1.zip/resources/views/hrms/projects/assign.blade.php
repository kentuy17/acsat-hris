@extends('hrms.layouts.base')

@section('content')

@endsection