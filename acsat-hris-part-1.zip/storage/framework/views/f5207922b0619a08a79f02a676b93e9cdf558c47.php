<?php /* D:\WorkDir\Thesis\acsat-hris\resources\views/pages/roles/add_role.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <form method="post" action="/add-role">
    <div class="row">
      <!-- Form -->
      
        <div class="col-md-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">General Elements</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body p25 p10">
              <form method="post" action="/add-role" class="form-horizontal">
                <div class="form-group row">
                  <!-- text input -->
                  <div class="col-md-3 control-label">
                    <label class="float-left">User Role</label>
                  </div>
                  <div class="col-md-6">
                    <input type="text" class="form-control" name="role" id="role" placeholder="Add Role">
                  </div>
                </div>
                <!-- desc input -->
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <label class="float-left">Description</label>
                  </div>
                  <div class="col-md-6">
                    <textarea name="description" id="description" class="form-control" rows="3" placeholder="Description"></textarea>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  </div>
                  <div class="col-md-6">
                    <button id="submit" type="submit" class="btn btn-primary float-right">Submit</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      
    </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
  Add Employee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('crumbs'); ?>
  <div class="col-sm-6">
    <ol class="breadcrumb float-sm-right">
      <li class="breadcrumb-item"><a href="<?php echo e(route('role-list')); ?>">User Roles</a></li>
      <li class="breadcrumb-item active">Add</li>
    </ol>
  </div><!-- /.col -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <!-- <script src="<?php echo e(URL::asset('assets/bower/plugins/bs-stepper/js/bs-stepper.min.js')); ?>"></script> -->
  <script src="<?php echo e(URL::asset('assets/bower/plugins/jquery/jquery.js')); ?>"></script>
  <!-- <script src="<?php echo e(URL::asset('assets/bower/js/jquery.datetimepicker.full.min.js')); ?>"></script> -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('jsfunction'); ?>
<script>
  document.getElementById("submit").addEventListener("click", function(){ 
    var required_fields = {
      'User Role': $('#role').val(),
    }

    for (const [key, value] of Object.entries(required_fields)) {
      if(!value){
        alert('Please fillup ' + key)
      }
    }
  })
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/bower/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/bower/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  <style>label.float-left{ margin-left: 150px; }</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('hrms.layouts.base3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>