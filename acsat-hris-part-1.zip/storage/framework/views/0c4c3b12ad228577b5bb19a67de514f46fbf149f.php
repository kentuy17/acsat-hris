<?php /* D:\WorkDir\Thesis\acsat-hris\resources\views/pages/sample.blade.php */ ?>
<?php

echo 'Hello World!';