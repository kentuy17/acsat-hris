<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <!-- <form method="post" action="/add-role"> -->
    <div class="row">
      <!-- Form -->
      
        <div class="col-md-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">File Leave</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body p25 p10">
              <form method="post" action="/apply-leave" class="form-horizontal">
                <div class="form-group row">
                  <!-- text input -->
                  <div class="col-md-3 control-label">
                    <label class="float-left">Type</label>
                  </div>
                  <div class="col-md-6">
                    <select class="form-control select2bs4" name="leave_type" id="leave_type" style="width: 100%;" required>
                      <option value="">Select</option>
                      <?php foreach($leaves as $leave): ?>
                        <option value="<?php echo e($leave->id); ?>"><?php echo e($leave->leave_type); ?> - <?php echo e($leave->description); ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>
                </div>
                <!-- desc input -->
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <label class="float-left">Reason</label>
                  </div>
                  <div class="col-md-6">
                    <textarea name="reason" id="reason" class="form-control" rows="3"></textarea>
                  </div>
                </div>
                <!-- desc Range -->
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <label class="float-left">From</label>
                  </div>
                  <!-- sample -->
                  <div class="input-group col-md-6">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                    </div>
                    <input type="date" name="date_from" id="date_from" value="<?php echo e(date('Y-m-d')); ?>" class="form-control" required>
                  </div>
                  <!-- end -->
                </div>
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <label class="float-left">To</label>
                  </div>
                  <div class="input-group col-md-6">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                    </div>
                    <input type="date" name="date_to" id="date_to" value="<?php echo e(date('Y-m-d')); ?>" class="form-control" required>
                  </div>
                </div>
                <div class="form-group row">
                  <div class="col-md-3 control-label">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                  </div>
                  <div class="col-md-6">
                    <button id="submit" type="submit" class="btn btn-primary float-right">Submit</button>
                  </div>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      
    </div>
    <!-- </form> -->
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?>
  Add Employee
<?php $__env->stopSection(); ?>

<?php $__env->startSection('crumbs'); ?>
  <div class="col-sm-6">
    <ol class="breadcrumb float-sm-right">
      <li class="breadcrumb-item"><a href="<?php echo e(route('my-leave-list')); ?>">My Leave List</a></li>
      <li class="breadcrumb-item active">Apply</li>
    </ol>
  </div><!-- /.col -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <!-- <script src="<?php echo e(URL::asset('assets/bower/plugins/bs-stepper/js/bs-stepper.min.js')); ?>"></script> -->
  <script src="<?php echo e(URL::asset('assets/bower/plugins/jquery/jquery.js')); ?>"></script>
  <!-- <script src="<?php echo e(URL::asset('assets/bower/js/jquery.datetimepicker.full.min.js')); ?>"></script> -->
<?php $__env->stopPush(); ?>

<?php $__env->startSection('jsfunction'); ?>
<script>
document.getElementById("submit").addEventListener("click", function(){ 
  var dateFrom = $('#date_from').val()
  var dateTo = $('#date_to').val()

  // if(!dateFrom){
  //   alert('Please select Date From')
  //   return false
  // }

  // if(!dateTo){
  //   alert('Please select Date To')
  //   return false
  // }
})
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/bower/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/bower/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  <style>label.float-left{ margin-left: 200px; }</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('hrms.layouts.base3', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>